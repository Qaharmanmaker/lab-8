class Author:
    def __init__(self, name, nationality):
        self.name = name
        self.nationality = nationality

    def __repr__(self):
        return f"Author(name={self.name!r}, nationality={self.nationality!r})"
