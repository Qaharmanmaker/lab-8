from author import Author

class Book:
    def __init__(self, title, author: Author):
        self.title = title
        self.author = author

    def __repr__(self):
        return f"Book(title={self.title!r}, author={self.author.name!r})"
